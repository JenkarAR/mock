package com.jsp.finalmock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalmockApplicationTests {

	@Test
	void contextLoads() {
	}

}
