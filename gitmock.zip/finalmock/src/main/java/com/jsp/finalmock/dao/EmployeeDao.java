package com.jsp.finalmock.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jsp.finalmock.dto.Employee;
import com.jsp.finalmock.repository.UserRepository;
@Component
public class EmployeeDao {
@Autowired
UserRepository repository;
public String saveData(Employee emp)
{
	repository.save(emp);
	return "data saved";
}
public String remove(int id)
{
	repository.deleteById(id);
	return "data deleted";
}
public Employee fetch(Employee employee)
{
	int id = employee.getEmp_id();
  Optional<Employee> O  = repository.findById(id);
  return O.get();
}
public List fetching() {
	// TODO Auto-generated method stub
  List <Employee> l  = repository.findAll();
  return l;
}
public void deleteAll() {
	repository.deleteAll();
}
public String updating(int emp_id, String name) {
	// TODO Auto-generated method stub
	Optional<Employee> G = repository.findById(emp_id);
	Employee employee = G.get();
	employee.setName(name);
	repository.save(employee);
	return "data saved";
}
}
