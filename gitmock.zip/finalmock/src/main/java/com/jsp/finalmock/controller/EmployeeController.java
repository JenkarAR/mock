package com.jsp.finalmock.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.finalmock.dao.EmployeeDao;
import com.jsp.finalmock.dto.Employee;

@RestController
public class EmployeeController {
	@Autowired
	EmployeeDao dao;
@PostMapping("/insert")
public String insertData(@RequestBody Employee emp)
{
String s = 	dao.saveData(emp);
return s;
}
@DeleteMapping("/delete")
public String deleteData(@RequestBody Employee employee)
{
	int id = employee.getEmp_id();
	String s = dao.remove(id);
	return s;
}
@GetMapping("/fetch")
public Employee fetchData(@RequestBody Employee employee)
{
	Employee d = dao.fetch(employee);
	return d;
}
@GetMapping("/fetchall")
public List fetchall()
{
	List<Employee>l = dao.fetching();
	return l;
}
@DeleteMapping("/deleteall")
public void deleteData()
{
	dao.deleteAll();
}
@PutMapping("/update")
public String update(@RequestBody Employee employee)
{
	String msg = dao.updating(employee.getEmp_id(),employee.getName());
	return msg;
}
}
