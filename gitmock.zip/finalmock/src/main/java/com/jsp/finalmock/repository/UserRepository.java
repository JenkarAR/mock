package com.jsp.finalmock.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.jsp.finalmock.dto.Employee;
@Component
public interface UserRepository extends JpaRepository<Employee, Integer>{
	
}
